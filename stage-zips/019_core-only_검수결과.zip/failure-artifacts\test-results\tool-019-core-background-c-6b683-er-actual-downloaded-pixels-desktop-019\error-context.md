# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tool-019-core.spec.ts >> background crop and zoom alter actual downloaded pixels
- Location: tests\tool-019-core.spec.ts:36:5

# Error details

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not 0
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main [ref=e2]:
    - generic [ref=e3]:
      - link "TOOLBOX 홈" [ref=e4] [cursor=pointer]:
        - /url: /ko
        - strong [ref=e5]: FIXLGS
        - generic [ref=e6]: TOOLBOX
      - navigation "주요 도구 / 카테고리" [ref=e7]:
        - link "주요 도구" [ref=e8] [cursor=pointer]:
          - /url: /ko#popular
        - link "카테고리" [ref=e9] [cursor=pointer]:
          - /url: /ko#categories
        - button "다크 모드" [ref=e10] [cursor=pointer]:
          - generic [ref=e11]: ☾
      - button "언어 선택" [ref=e15] [cursor=pointer]:
        - generic [ref=e16]: 한국어
        - generic [ref=e17]: ⌄
    - generic [ref=e18]:
      - link "← 콘텐츠 이미지 제작" [ref=e19] [cursor=pointer]:
        - /url: /ko/category/content-image
      - paragraph [ref=e20]: 019 · CONTENT IMAGE
      - generic [ref=e21]:
        - heading "유튜브 썸네일 제작기" [level=1] [ref=e22]
        - paragraph [ref=e24]: 배경 이미지와 제목·부제를 넣어 16:9 유튜브 썸네일을 간편하게 만드세요.
      - generic [ref=e25]:
        - strong [ref=e26]: LOCAL
        - generic [ref=e27]: 브라우저에서 바로 처리
    - generic [ref=e29]:
      - generic [ref=e30]:
        - generic [ref=e31]:
          - generic [ref=e32]:
            - strong [ref=e33]: 유튜브 썸네일 제작 작업장
            - generic [ref=e34]:
              - button "실행 취소" [ref=e35] [cursor=pointer]
              - button "다시 실행" [disabled] [ref=e36]
          - generic [ref=e37]:
            - generic [ref=e38]:
              - generic "썸네일 편집 미리보기" [ref=e40]
              - paragraph [ref=e41]: 원본 이미지 해상도가 낮아 확대하면 흐려질 수 있습니다.
              - paragraph [ref=e42]: 미리보기에서 배경·제목·부제를 선택한 뒤 직접 드래그해 위치를 조절할 수 있습니다.
              - paragraph [ref=e45]: 작은 화면 미리보기
            - complementary [ref=e46]:
              - generic [ref=e47]:
                - generic [ref=e48]:
                  - heading "배경" [level=4] [ref=e49]
                  - generic [ref=e50]: SELECTED
                - button "배경 편집" [ref=e51] [cursor=pointer]
                - generic [ref=e52]:
                  - button "채우기" [ref=e53] [cursor=pointer]
                  - button "전체 보기" [ref=e54] [cursor=pointer]
                - button "배경 맞춤 초기화" [ref=e55] [cursor=pointer]
                - generic [ref=e56]:
                  - text: 배경 확대
                  - slider "배경 확대" [ref=e57]: "160"
                - generic [ref=e58]:
                  - text: 배경 밝기 조절
                  - slider "배경 밝기 조절" [ref=e59]: "0"
                - generic [ref=e60]:
                  - text: 배경색
                  - textbox "배경색" [ref=e61]: "#111111"
                - generic [ref=e62]:
                  - checkbox "가독성 안전 가이드" [checked] [ref=e63]
                  - text: 가독성 안전 가이드
                - generic [ref=e64]:
                  - checkbox "삼등분 가이드" [ref=e65]
                  - text: 삼등분 가이드
                - generic [ref=e66]:
                  - button "이미지 교체" [ref=e67] [cursor=pointer]
                  - button "이미지 제거" [ref=e68] [cursor=pointer]
              - generic [ref=e69]:
                - heading "제목" [level=4] [ref=e71]
                - button "이 항목 편집" [ref=e72] [cursor=pointer]
                - generic [ref=e73]:
                  - checkbox "표시" [ref=e74]
                  - text: 표시
                - generic [ref=e75]:
                  - text: 문구
                  - textbox "문구" [ref=e76]: 유튜브 썸네일 제목
                - generic [ref=e77]:
                  - generic [ref=e78]:
                    - text: 글자 크기
                    - spinbutton "글자 크기" [ref=e79]: "86"
                  - generic [ref=e80]:
                    - text: 줄간격
                    - spinbutton "줄간격" [ref=e81]: "1.18"
                - generic [ref=e82]:
                  - text: 글자 영역 폭
                  - spinbutton "글자 영역 폭" [ref=e83]: "1120"
                - generic [ref=e84]:
                  - text: 글꼴
                  - combobox "글꼴" [ref=e85]:
                    - option "기본 고딕"
                    - option "굵은 고딕" [selected]
                    - option "세리프"
                    - option "임팩트 계열"
                - generic [ref=e86]:
                  - checkbox "굵게" [checked] [ref=e87]
                  - text: 굵게
                - generic [ref=e88]:
                  - text: 글자 색상
                  - textbox "글자 색상" [ref=e89]: "#ffffff"
                - generic [ref=e90]:
                  - button "←" [ref=e91]
                  - button "↔" [ref=e92]
                  - button "→" [ref=e93]
                - generic [ref=e94]: 빠른 위치
                - generic [ref=e95]:
                  - button "← ↑" [ref=e96] [cursor=pointer]
                  - button "• ↑" [ref=e97] [cursor=pointer]
                  - button "→ ↑" [ref=e98] [cursor=pointer]
                  - button "← •" [ref=e99] [cursor=pointer]
                  - button "• •" [ref=e100] [cursor=pointer]
                  - button "→ •" [ref=e101] [cursor=pointer]
                  - button "← ↓" [ref=e102] [cursor=pointer]
                  - button "• ↓" [ref=e103] [cursor=pointer]
                  - button "→ ↓" [ref=e104] [cursor=pointer]
                - button "위치 초기화" [ref=e105] [cursor=pointer]
                - generic [ref=e106]:
                  - checkbox "외곽선 사용" [checked] [ref=e107]
                  - text: 외곽선 사용
                - generic [ref=e108]:
                  - generic [ref=e109]:
                    - text: 외곽선 두께
                    - spinbutton "외곽선 두께" [ref=e110]: "7"
                  - generic [ref=e111]:
                    - text: 외곽선 색상
                    - textbox "외곽선 색상" [ref=e112]: "#000000"
                - generic [ref=e113]:
                  - checkbox "그림자 사용" [ref=e114]
                  - text: 그림자 사용
                - generic [ref=e115]:
                  - checkbox "글자 배경 사용" [ref=e116]
                  - text: 글자 배경 사용
              - generic [ref=e117]:
                - heading "부제" [level=4] [ref=e119]
                - button "이 항목 편집" [ref=e120] [cursor=pointer]
                - generic [ref=e121]:
                  - checkbox "표시" [ref=e122]
                  - text: 표시
                - generic [ref=e123]:
                  - text: 문구
                  - textbox "문구" [ref=e124]: 부제목을 입력하세요
                - generic [ref=e125]:
                  - generic [ref=e126]:
                    - text: 글자 크기
                    - spinbutton "글자 크기" [ref=e127]: "42"
                  - generic [ref=e128]:
                    - text: 줄간격
                    - spinbutton "줄간격" [ref=e129]: "1.18"
                - generic [ref=e130]:
                  - text: 글자 영역 폭
                  - spinbutton "글자 영역 폭" [ref=e131]: "1120"
                - generic [ref=e132]:
                  - text: 글꼴
                  - combobox "글꼴" [ref=e133]:
                    - option "기본 고딕" [selected]
                    - option "굵은 고딕"
                    - option "세리프"
                    - option "임팩트 계열"
                - generic [ref=e134]:
                  - checkbox "굵게" [checked] [ref=e135]
                  - text: 굵게
                - generic [ref=e136]:
                  - text: 글자 색상
                  - textbox "글자 색상" [ref=e137]: "#ffffff"
                - generic [ref=e138]:
                  - button "←" [ref=e139]
                  - button "↔" [ref=e140]
                  - button "→" [ref=e141]
                - generic [ref=e142]: 빠른 위치
                - generic [ref=e143]:
                  - button "← ↑" [ref=e144] [cursor=pointer]
                  - button "• ↑" [ref=e145] [cursor=pointer]
                  - button "→ ↑" [ref=e146] [cursor=pointer]
                  - button "← •" [ref=e147] [cursor=pointer]
                  - button "• •" [ref=e148] [cursor=pointer]
                  - button "→ •" [ref=e149] [cursor=pointer]
                  - button "← ↓" [ref=e150] [cursor=pointer]
                  - button "• ↓" [ref=e151] [cursor=pointer]
                  - button "→ ↓" [ref=e152] [cursor=pointer]
                - button "위치 초기화" [ref=e153] [cursor=pointer]
                - generic [ref=e154]:
                  - checkbox "외곽선 사용" [checked] [ref=e155]
                  - text: 외곽선 사용
                - generic [ref=e156]:
                  - generic [ref=e157]:
                    - text: 외곽선 두께
                    - spinbutton "외곽선 두께" [ref=e158]: "4"
                  - generic [ref=e159]:
                    - text: 외곽선 색상
                    - textbox "외곽선 색상" [ref=e160]: "#000000"
                - generic [ref=e161]:
                  - checkbox "그림자 사용" [ref=e162]
                  - text: 그림자 사용
                - generic [ref=e163]:
                  - checkbox "글자 배경 사용" [ref=e164]
                  - text: 글자 배경 사용
              - generic [ref=e165]:
                - heading "출력" [level=4] [ref=e166]
                - generic [ref=e167]:
                  - text: 출력 해상도
                  - combobox "출력 해상도" [ref=e168]:
                    - option "표준 1280×720" [selected]
                    - option "고해상도 3840×2160"
                - generic [ref=e169]:
                  - text: 출력 형식
                  - combobox "출력 형식" [ref=e170]:
                    - option "JPG"
                    - option "PNG" [selected]
                - generic [ref=e171]:
                  - text: 파일명
                  - textbox "파일명" [ref=e172]: crop-probe-thumbnail.png
        - generic [ref=e173]:
          - generic [ref=e174]:
            - generic [ref=e175]:
              - generic [ref=e176]: 결과 크기
              - strong [ref=e177]: 1280 × 720
            - generic [ref=e178]:
              - generic [ref=e179]: 비율
              - strong [ref=e180]: 16:9
            - generic [ref=e181]:
              - generic [ref=e182]: 출력 형식
              - strong [ref=e183]: PNG
            - generic [ref=e184]:
              - generic [ref=e185]: YouTube 모바일 참고
              - strong [ref=e186]: 2 MB
            - generic [ref=e187]:
              - generic [ref=e188]: YouTube 데스크톱 참고
              - strong [ref=e189]: 50 MB
            - generic [ref=e190]:
              - generic [ref=e191]: 파일 용량
              - strong [ref=e192]: 20 KB
          - paragraph [ref=e193]: "가독성 안전 가이드는 YouTube 공식 픽셀 규격이 아닌 편집 보조 가이드이며 최종 이미지에는 포함되지 않습니다. YouTube 공식 참고: 3840×2160 권장, 모바일 2MB·데스크톱 50MB 제한(2026-08-09 확인). 업로드 전 최신 공식 안내를 다시 확인하세요."
          - paragraph [ref=e194]: 현재 파일은 모바일 참고 제한 이내입니다.
          - generic [ref=e195]:
            - button "다시 다운로드" [active] [ref=e196] [cursor=pointer]
            - button "전체 초기화" [ref=e197] [cursor=pointer]
          - paragraph [ref=e198]: 다운로드 준비 완료
      - generic [ref=e199]:
        - generic [ref=e200]:
          - paragraph [ref=e201]: NEXT WORK
          - heading "다음 작업" [level=2] [ref=e202]
        - article [ref=e204]:
          - text: "020"
          - heading "유튜브 채널 배너 제작기" [level=3] [ref=e205]
          - generic [ref=e206]:
            - generic [ref=e207]: 준비 중
            - strong [ref=e208]: ↗
      - generic [ref=e209]:
        - generic [ref=e210]:
          - paragraph [ref=e211]: RELATED TOOLS
          - heading "관련 도구" [level=2] [ref=e212]
        - generic [ref=e213]:
          - link "016 이미지에 글자 넣기 사용 가능 ↗" [ref=e214] [cursor=pointer]:
            - /url: /ko/add-text-to-image
            - text: "016"
            - heading "이미지에 글자 넣기" [level=3] [ref=e215]
            - generic [ref=e216]:
              - generic [ref=e217]: 사용 가능
              - strong [ref=e218]: ↗
          - link "009 이미지 밝기·색상 보정기 사용 가능 ↗" [ref=e219] [cursor=pointer]:
            - /url: /ko/image-brightness-color-adjuster
            - text: "009"
            - heading "이미지 밝기·색상 보정기" [level=3] [ref=e220]
            - generic [ref=e221]:
              - generic [ref=e222]: 사용 가능
              - strong [ref=e223]: ↗
          - link "008 이미지 자르기·회전 도구 사용 가능 ↗" [ref=e224] [cursor=pointer]:
            - /url: /ko/image-cropper-rotator
            - text: "008"
            - heading "이미지 자르기·회전 도구" [level=3] [ref=e225]
            - generic [ref=e226]:
              - generic [ref=e227]: 사용 가능
              - strong [ref=e228]: ↗
          - link "006 이미지 크기 변경기 사용 가능 ↗" [ref=e229] [cursor=pointer]:
            - /url: /ko/image-resizer
            - text: "006"
            - heading "이미지 크기 변경기" [level=3] [ref=e230]
            - generic [ref=e231]:
              - generic [ref=e232]: 사용 가능
              - strong [ref=e233]: ↗
          - link "004 이미지 압축기 사용 가능 ↗" [ref=e234] [cursor=pointer]:
            - /url: /ko/image-compressor
            - text: "004"
            - heading "이미지 압축기" [level=3] [ref=e235]
            - generic [ref=e236]:
              - generic [ref=e237]: 사용 가능
              - strong [ref=e238]: ↗
    - generic [ref=e239]:
      - generic [ref=e240]:
        - paragraph [ref=e241]: HOW TO USE
        - heading "사용 방법" [level=2] [ref=e242]
      - list [ref=e243]:
        - listitem [ref=e244]:
          - generic [ref=e245]: "01"
          - paragraph [ref=e246]: 썸네일에 사용할 JPG, PNG 또는 WebP 배경 이미지를 선택합니다.
        - listitem [ref=e247]:
          - generic [ref=e248]: "02"
          - paragraph [ref=e249]: 제목·부제를 입력하고 이미지 위치, 글자, 외곽선과 그림자를 조절합니다.
        - listitem [ref=e250]:
          - generic [ref=e251]: "03"
          - paragraph [ref=e252]: 가독성 안전 가이드와 파일 크기를 확인하고 1280×720 또는 3840×2160 썸네일을 다운로드합니다.
    - generic [ref=e253]:
      - generic [ref=e254]:
        - paragraph [ref=e255]: USE CASES
        - heading "활용 예시" [level=2] [ref=e256]
      - generic [ref=e258]:
        - article [ref=e259]:
          - strong [ref=e260]: "01"
          - heading "유튜브 일반 영상 썸네일" [level=3] [ref=e261]
          - paragraph [ref=e262]: 일반 영상에 사용할 핵심 제목과 배경 이미지를 16:9 한 화면에 정리합니다.
        - article [ref=e263]:
          - strong [ref=e264]: "02"
          - heading "제품 리뷰·쇼핑 영상" [level=3] [ref=e265]
          - paragraph [ref=e266]: 제품 사진과 짧은 핵심 문구를 조합해 리뷰·비교·쇼핑 영상용 썸네일을 만듭니다.
        - article [ref=e267]:
          - strong [ref=e268]: "03"
          - heading "강의·교육 콘텐츠" [level=3] [ref=e269]
          - paragraph [ref=e270]: 강의 주제나 핵심 키워드가 작은 화면에서도 빠르게 읽히도록 제목 중심으로 구성합니다.
        - article [ref=e271]:
          - strong [ref=e272]: "04"
          - heading "여행·음식·브이로그" [level=3] [ref=e273]
          - paragraph [ref=e274]: 사진의 분위기는 살리면서 장소·메뉴·에피소드 같은 핵심 문구를 함께 배치합니다.
        - article [ref=e275]:
          - strong [ref=e276]: "05"
          - heading "앱·서비스 소개 영상" [level=3] [ref=e277]
          - paragraph [ref=e278]: 앱 화면이나 서비스 이미지를 배경으로 두고 기능명·핵심 특징을 제목과 부제로 정리합니다.
        - article [ref=e279]:
          - strong [ref=e280]: "06"
          - heading "비교·정보 영상" [level=3] [ref=e281]
          - paragraph [ref=e282]: 비교 대상이나 핵심 결론을 짧은 문구로 강조해 정보의 주제를 한눈에 전달합니다.
    - generic [ref=e283]:
      - generic [ref=e284]:
        - paragraph [ref=e285]: EXPERT POST
        - heading "유튜브 썸네일을 안정적으로 만드는 실전 기준" [level=2] [ref=e286]
        - generic [ref=e287]: 캔버스 비율부터 글자 가독성·출력 형식·실제 파일 용량까지, 썸네일 제작 결과에 직접 영향을 주는 기준을 실제 작업 흐름에 맞춰 정리했습니다.
      - generic [ref=e289]:
        - article [ref=e290]:
          - heading "16:9 캔버스와 원본 비율" [level=4] [ref=e291]
          - paragraph [ref=e292]: 출력 캔버스는 16:9로 고정되지만 원본 사진까지 16:9일 필요는 없습니다. 채우기는 캔버스를 가득 채우는 대신 가장자리가 잘릴 수 있고, 전체 보기는 원본 전체를 유지하는 대신 빈 영역이 생길 수 있습니다.
        - article [ref=e293]:
          - heading "제목은 작은 화면 기준으로 확인" [level=4] [ref=e294]
          - paragraph [ref=e295]: 썸네일은 큰 편집 화면보다 실제 목록이나 모바일처럼 축소된 상태에서 먼저 읽혀야 합니다. 제목 길이, 글자 크기, 외곽선과 배경 대비는 작은 화면 미리보기에서 최종 확인하는 것이 좋습니다.
        - article [ref=e296]:
          - heading "외곽선과 그림자의 역할" [level=4] [ref=e297]
          - paragraph [ref=e298]: 외곽선은 글자와 배경의 경계를 분리하고 그림자는 깊이와 방향감을 더합니다. 두 효과를 동시에 과하게 적용하면 글자가 두꺼워지고 가장자리가 뭉개질 수 있으므로 필요한 만큼만 사용하는 것이 좋습니다.
        - article [ref=e299]:
          - heading "안전 가이드는 편집 보조선" [level=4] [ref=e300]
          - paragraph [ref=e301]: 가독성 안전 가이드는 중요한 제목과 피사체를 화면 가장자리에 너무 가깝게 두지 않도록 돕는 TOOLBOX 편집 보조선입니다. YouTube의 공식 픽셀 안전영역 규격으로 해석하지 않으며 최종 이미지에는 포함되지 않습니다.
        - article [ref=e302]:
          - heading "1280×720과 3840×2160" [level=4] [ref=e303]
          - paragraph [ref=e304]: 두 출력 크기는 모두 16:9입니다. 일반 제작에는 1280×720이 가볍고, 더 큰 원본을 활용하거나 고해상도 보관본이 필요하면 3840×2160을 선택할 수 있습니다. 작은 원본을 큰 출력으로 저장한다고 실제 디테일이 새로 생기지는 않습니다.
        - article [ref=e305]:
          - heading "JPG 품질과 실제 파일 용량" [level=4] [ref=e306]
          - paragraph [ref=e307]: JPG는 품질값을 낮추면 대체로 파일 용량이 줄지만 배경의 세부 묘사와 글자 주변에 압축 흔적이 보일 수 있습니다. 2MB 이하 맞추기는 실제 생성 결과를 기준으로 품질을 조정하며 결과 화면에서 최종 용량을 다시 확인해야 합니다.
        - article [ref=e308]:
          - heading "PNG와 사진형 배경" [level=4] [ref=e309]
          - paragraph [ref=e310]: PNG는 글자와 단순 그래픽의 경계를 선명하게 보존하는 데 유리하지만 사진형 배경에서는 JPG보다 파일이 크게 나올 수 있습니다. 같은 디자인이라도 출력 형식에 따라 용량 차이가 커질 수 있습니다.
        - article [ref=e311]:
          - heading "브라우저 로컬 처리와 최종 확인" [level=4] [ref=e312]
          - paragraph [ref=e313]: 이미지와 입력 문구는 현재 브라우저에서 처리되며 원본 파일 자체를 수정하지 않습니다. 다운로드 전에는 최종 해상도, 형식, 품질, 파일명과 실제 생성 용량을 한 번 더 확인하는 것이 안전합니다.
    - generic [ref=e315]:
      - paragraph [ref=e316]: SAFE AREA
      - heading "안전영역과 파일 용량" [level=2] [ref=e317]
      - generic [ref=e318]:
        - generic [ref=e319]: 가독성 안전 가이드는 YouTube 공식 픽셀 안전영역이 아닌 TOOLBOX 편집 보조 가이드이며 최종 결과 파일에는 포함되지 않습니다.
        - generic [ref=e320]: 중요한 제목·로고·주요 피사체는 화면 가장자리보다 안쪽에 배치하면 다양한 화면 크기에서도 가독성을 유지하기 쉽습니다.
        - generic [ref=e321]: JPG는 사진 중심 썸네일의 용량 관리에 유리하고, PNG는 글자·그래픽 경계를 선명하게 유지하는 대신 사진 배경에서 용량이 커질 수 있습니다.
        - generic [ref=e322]: 파일 용량은 추정치가 아니라 실제 생성된 결과를 기준으로 표시하므로 다운로드 전 해상도·형식·품질과 함께 최종 용량을 확인하세요.
    - generic [ref=e323]:
      - generic [ref=e324]:
        - paragraph [ref=e325]: IMPORTANT NOTES
        - heading "주의사항" [level=2] [ref=e326]
      - article [ref=e329]:
        - list [ref=e330]:
          - listitem [ref=e331]: 기본 출력은 16:9 1280×720이며, 고해상도 3840×2160 출력도 선택할 수 있습니다.
          - listitem [ref=e332]: YouTube 공식 권장 해상도와 업로드 제한은 변경될 수 있으므로 업로드 전 최신 공식 안내를 확인하세요.
          - listitem [ref=e333]: 작은 원본 이미지를 크게 확대하면 배경이 흐려질 수 있습니다.
          - listitem [ref=e334]: 채우기 모드에서는 배경 이미지 일부가 잘릴 수 있습니다.
          - listitem [ref=e335]: 가독성 안전 가이드는 YouTube 공식 픽셀 안전영역이 아닌 TOOLBOX 편집 보조 가이드입니다.
          - listitem [ref=e336]: PNG는 사진 배경에서 JPG보다 용량이 커질 수 있습니다.
          - listitem [ref=e337]: JPG 품질을 낮추면 파일 용량은 줄지만 화질도 낮아질 수 있습니다.
          - listitem [ref=e338]: TOOLBOX는 썸네일 클릭률이나 영상 성과를 예측하지 않습니다.
    - generic [ref=e339]:
      - generic [ref=e340]:
        - paragraph [ref=e341]: FAQ
        - heading "자주 묻는 질문" [level=2] [ref=e342]
      - generic [ref=e343]:
        - group [ref=e344]:
          - generic "01 유튜브 썸네일 권장 크기는 얼마인가요? +" [ref=e345] [cursor=pointer]:
            - generic [ref=e346]: "01"
            - text: 유튜브 썸네일 권장 크기는 얼마인가요?
            - generic [ref=e347]: +
          - paragraph [ref=e348]: TOOLBOX 기본 제작 크기는 1280×720이며, 3840×2160 고해상도 출력도 선택할 수 있습니다. 두 규격 모두 16:9입니다.
        - group [ref=e349]:
          - generic "02 사진 비율이 16:9가 아니어도 되나요? +" [ref=e350] [cursor=pointer]:
            - generic [ref=e351]: "02"
            - text: 사진 비율이 16:9가 아니어도 되나요?
            - generic [ref=e352]: +
        - group [ref=e353]:
          - generic "03 제목을 여러 줄로 쓸 수 있나요? +" [ref=e354] [cursor=pointer]:
            - generic [ref=e355]: "03"
            - text: 제목을 여러 줄로 쓸 수 있나요?
            - generic [ref=e356]: +
        - group [ref=e357]:
          - generic "04 제목 위치를 직접 옮길 수 있나요? +" [ref=e358] [cursor=pointer]:
            - generic [ref=e359]: "04"
            - text: 제목 위치를 직접 옮길 수 있나요?
            - generic [ref=e360]: +
        - group [ref=e361]:
          - generic "05 글자에 테두리와 그림자를 넣을 수 있나요? +" [ref=e362] [cursor=pointer]:
            - generic [ref=e363]: "05"
            - text: 글자에 테두리와 그림자를 넣을 수 있나요?
            - generic [ref=e364]: +
        - button "FAQ 더보기" [ref=e366] [cursor=pointer]
    - paragraph [ref=e368]: 이미지와 입력한 문구는 서버로 전송되지 않으며 현재 브라우저에서 처리됩니다.
    - generic [ref=e369]:
      - link "TOOLBOX 홈" [ref=e370] [cursor=pointer]:
        - /url: /ko
      - generic [ref=e371]: TOOLBOX · 2026
      - generic [ref=e372]:
        - link "개인정보처리방침" [ref=e373] [cursor=pointer]:
          - /url: https://fixlgs.com/privacy
        - link "이용약관" [ref=e374] [cursor=pointer]:
          - /url: https://fixlgs.com/terms
        - link "문의하기" [ref=e375] [cursor=pointer]:
          - /url: https://fixlgs.com/contact?app=%EC%9C%A0%ED%8A%9C%EB%B8%8C%20%EC%8D%B8%EB%84%A4%EC%9D%BC%20%EC%A0%9C%EC%9E%91%EA%B8%B0
  - button "Open Next.js Dev Tools" [ref=e381] [cursor=pointer]
  - alert [ref=e385]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {readFile} from 'node:fs/promises';
  3  | import {upload019,openTool019,tool019BackgroundPanel,tool019Root,tool019TextPanel,TOOL019_TESTIDS} from './helpers/tool-019';
  4  | 
  5  | async function sampleDownloadedPixel(page:any,bytes:Buffer,x:number,y:number){
  6  |   return await page.evaluate(async({arr,x,y}:{arr:number[],x:number,y:number})=>{
  7  |     const blob=new Blob([new Uint8Array(arr)],{type:'image/png'});const bmp=await createImageBitmap(blob);const c=document.createElement('canvas');c.width=bmp.width;c.height=bmp.height;const ctx=c.getContext('2d')!;ctx.drawImage(bmp,0,0);return Array.from(ctx.getImageData(x,y,1,1).data);
  8  |   },{arr:Array.from(bytes),x,y});
  9  | }
  10 | 
  11 | test.describe('019 core-only',()=>{
  12 |  test('renders 1280x720 editor and small preview',async({page})=>{await upload019(page);const c=page.getByTestId(TOOL019_TESTIDS.preview);await expect(c).toHaveAttribute('width','1280');await expect(c).toHaveAttribute('height','720');await expect(page.getByTestId(TOOL019_TESTIDS.small)).toBeVisible();});
  13 |  test('title and subtitle are independently editable',async({page})=>{await upload019(page);await page.getByTestId(TOOL019_TESTIDS.title).fill('한글 제목');await page.getByTestId(TOOL019_TESTIDS.subtitle).fill('부제');await expect(page.getByTestId(TOOL019_TESTIDS.title)).toHaveValue('한글 제목');await expect(page.getByTestId(TOOL019_TESTIDS.subtitle)).toHaveValue('부제');});
  14 |  test('downloaded PNG is exact 1280x720 and safe guide is absent from output pixels',async({page},testInfo)=>{await openTool019(page);await tool019Root(page).getByRole('button',{name:/단색 배경/}).click();await tool019Root(page).getByLabel('출력 형식').selectOption('png');const d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();const dl=await d;const out=testInfo.outputPath('tool019.png');await dl.saveAs(out);const b=await readFile(out);expect(b.subarray(1,4).toString()).toBe('PNG');expect(b.readUInt32BE(16)).toBe(1280);expect(b.readUInt32BE(20)).toBe(720);const px=await sampleDownloadedPixel(page,b,80,50);expect(px.slice(0,3)).toEqual([17,17,17]);});
  15 |  test('font, quick position, text background and full shadow controls are wired',async({page})=>{await upload019(page);await page.getByTestId('tool019-title-font').selectOption('serif');await expect(page.getByTestId('tool019-title-font')).toHaveValue('serif');const titlePanel=tool019TextPanel(page,'title');await titlePanel.getByText('그림자 사용',{exact:true}).locator('input').check();await page.getByTestId('tool019-title-shadow-color').fill('#223344');await page.getByTestId('tool019-title-shadow-opacity').fill('70');await page.getByTestId('tool019-title-shadow-blur').fill('12');await page.getByTestId('tool019-title-shadow-x').fill('6');await page.getByTestId('tool019-title-shadow-y').fill('8');await expect(page.getByTestId('tool019-title-shadow-opacity')).toHaveValue('70');await expect(titlePanel.getByRole('button',{name:'위치 초기화'})).toBeVisible();await titlePanel.getByText('글자 배경 사용',{exact:true}).locator('input').check();await page.getByTestId('tool019-title-text-bg-opacity').fill('65');await expect(page.getByTestId('tool019-title-text-bg-opacity')).toHaveValue('65');});
  16 |  test('displayed Blob size matches downloaded file byte size',async({page},testInfo)=>{await upload019(page);await tool019Root(page).getByLabel('출력 형식').selectOption('png');await expect(page.getByTestId(TOOL019_TESTIDS.fileSize)).not.toHaveText('—',{timeout:5000});const d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();const dl=await d;const out=testInfo.outputPath('size-check.png');await dl.saveAs(out);const bytes=(await readFile(out)).length;const displayed=(await page.getByTestId(TOOL019_TESTIDS.fileSize).innerText()).trim();const expected=bytes<1024*1024?`${(bytes/1024).toFixed(0)} KB`:`${(bytes/1024/1024).toFixed(2)} MB`;expect(displayed).toBe(expected);});
  17 |  test('JPG quality changes actual output size for stable fixture',async({page},testInfo)=>{await upload019(page);const q=page.getByTestId(TOOL019_TESTIDS.quality);await q.fill('100');let d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();let dl=await d;const hi=testInfo.outputPath('q100.jpg');await dl.saveAs(hi);await q.fill('60');d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();dl=await d;const lo=testInfo.outputPath('q60.jpg');await dl.saveAs(lo);expect((await readFile(lo)).length).toBeLessThan((await readFile(hi)).length);});
  18 | });
  19 | 
  20 | test('high resolution output is actual 3840x2160 and preserves 16:9',async({page},testInfo)=>{await openTool019(page);await tool019Root(page).getByRole('button',{name:/단색 배경/}).click();await page.getByTestId('tool019-resolution').selectOption('high');await tool019Root(page).getByLabel('출력 형식').selectOption('png');const d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();const dl=await d;const out=testInfo.outputPath('tool019-4k.png');await dl.saveAs(out);const b=await readFile(out);expect(b.readUInt32BE(16)).toBe(3840);expect(b.readUInt32BE(20)).toBe(2160);});
  21 | 
  22 | test('safe content and thirds guides are preview-only',async({page},testInfo)=>{await openTool019(page);await tool019Root(page).getByRole('button',{name:/단색 배경/}).click();await tool019Root(page).getByLabel('출력 형식').selectOption('png');await expect(tool019Root(page).getByLabel('출력 형식')).toHaveValue('png');const points=[[64,36],[427,240],[853,480]] as const;async function pixels(name:string){const d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();const dl=await d;const out=testInfo.outputPath(name);await dl.saveAs(out);const b=await readFile(out);expect(b.subarray(1,4).toString()).toBe('PNG');return Promise.all(points.map(([x,y])=>sampleDownloadedPixel(page,b,x,y)));}await page.getByTestId('tool019-safe-guide').uncheck();await page.getByTestId('tool019-thirds-guide').uncheck();const withoutGuides=await pixels('guides-off-output.png');await page.getByTestId('tool019-safe-guide').check();await page.getByTestId('tool019-thirds-guide').check();const withGuides=await pixels('guides-on-preview-only-output.png');expect(withGuides).toEqual(withoutGuides);});
  23 | 
  24 | test('fit under 2MB control is JPG-only and bounded',async({page})=>{await openTool019(page);await tool019Root(page).getByRole('button',{name:/단색 배경/}).click();await expect(page.getByTestId('tool019-fit-2mb')).toBeVisible();await page.getByTestId('tool019-fit-2mb').click();await expect(page.getByTestId(TOOL019_TESTIDS.status)).toContainText(/2MB|2 MB/);await tool019Root(page).getByLabel('출력 형식').selectOption('png');await expect(page.getByTestId('tool019-fit-2mb')).toHaveCount(0);});
  25 | 
  26 | test('actual output contains title/subtitle/outline/shadow pixels',async({page},testInfo)=>{
  27 |  await openTool019(page);await tool019Root(page).getByRole('button',{name:/단색 배경/}).click();
  28 |  await page.getByTestId(TOOL019_TESTIDS.title).fill('TITLE');await page.getByTestId(TOOL019_TESTIDS.subtitle).fill('SUB');
  29 |  const titlePanel=tool019TextPanel(page,'title');await titlePanel.getByText('그림자 사용',{exact:true}).locator('input').check();
  30 |  await page.getByTestId('tool019-title-shadow-color').fill('#00ff00');await page.getByTestId('tool019-title-shadow-opacity').fill('100');await page.getByTestId('tool019-title-shadow-blur').fill('0');await page.getByTestId('tool019-title-shadow-x').fill('14');await page.getByTestId('tool019-title-shadow-y').fill('14');
  31 |  await tool019Root(page).getByLabel('출력 형식').selectOption('png');const d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();const dl=await d;const out=testInfo.outputPath('text-pixels.png');await dl.saveAs(out);const b=await readFile(out);
  32 |  const stats=await page.evaluate(async arr=>{const blob=new Blob([new Uint8Array(arr)],{type:'image/png'});const bmp=await createImageBitmap(blob);const c=document.createElement('canvas');c.width=bmp.width;c.height=bmp.height;const x=c.getContext('2d')!;x.drawImage(bmp,0,0);const p=x.getImageData(0,0,c.width,c.height).data;let light=0,dark=0,green=0;for(let i=0;i<p.length;i+=4){if(p[i]>220&&p[i+1]>220&&p[i+2]>220)light++;if(p[i]<40&&p[i+1]<40&&p[i+2]<40)dark++;if(p[i]<80&&p[i+1]>160&&p[i+2]<80)green++;}return{light,dark,green};},Array.from(b));
  33 |  expect(stats.light).toBeGreaterThan(100);expect(stats.dark).toBeGreaterThan(100);expect(stats.green).toBeGreaterThan(20);
  34 | });
  35 | 
  36 | test('background crop and zoom alter actual downloaded pixels',async({page},testInfo)=>{
  37 |  await openTool019(page);await page.getByTestId(TOOL019_TESTIDS.fileInput).setInputFiles('test-fixtures/crop-probe.jpg');await expect(page.getByTestId(TOOL019_TESTIDS.preview)).toBeVisible();
  38 |  await tool019Root(page).getByRole('button',{name:'배경 편집'}).click();await tool019Root(page).getByLabel('출력 형식').selectOption('png');const canvas=page.getByTestId(TOOL019_TESTIDS.preview);const box=await canvas.boundingBox();expect(box).toBeTruthy();
  39 |  // Hide text overlays so hitTarget() can only resolve the drag as background.
  40 |  for(const kind of ['title','subtitle'] as const){const panel=tool019TextPanel(page,kind);const show=panel.getByText('표시',{exact:true}).locator('input');await show.uncheck();await expect(show).not.toBeChecked();}
  41 |  async function outputBytes(name:string){const d=page.waitForEvent('download');await page.getByTestId(TOOL019_TESTIDS.download).click();const dl=await d;const out=testInfo.outputPath(name);await dl.saveAs(out);return readFile(out)}
  42 |  const zoom=tool019BackgroundPanel(page).getByLabel('배경 확대');await zoom.fill('160');await expect(zoom).toHaveValue('160');const before=await outputBytes('crop-before.png');
  43 |  if(box){const x=box.x+box.width*.5,y=box.y+box.height*.5;await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x,y-box.height*.25,{steps:8});await page.mouse.up();}
> 44 |  const moved=await outputBytes('crop-after.png');expect(Buffer.compare(moved,before)).not.toBe(0);
     |                                                                                           ^ Error: expect(received).not.toBe(expected) // Object.is equality
  45 |  await zoom.fill('200');await expect(zoom).toHaveValue('200');const zoomed=await outputBytes('zoom-after.png');expect(Buffer.compare(zoomed,moved)).not.toBe(0);
  46 | });
  47 | 
  48 | test('line height is independently adjustable for title and subtitle',async({page})=>{await upload019(page);const title=page.getByTestId('tool019-title-line-height'),subtitle=page.getByTestId('tool019-subtitle-line-height');await title.fill('1.30');await subtitle.fill('1.45');expect(Number(await title.inputValue())).toBeCloseTo(1.3,5);expect(Number(await subtitle.inputValue())).toBeCloseTo(1.45,5);});
  49 | 
```